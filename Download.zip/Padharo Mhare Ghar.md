॥ श्री गणेशाय नमः ॥

# पधारो म्हारे घर

Padharo Mhare Ghar · you are invited

Tap the doors to enter

Join us for our

## गृह प्रवेश

Griha Pravesh · The Vyas Family

Our new home · Pokaran

With the blessings of the Almighty, we are stepping into our new home and would love to share the day with you.

Mark your calendar

## November 2026

SMTWTFS

### Friday, 6 November 2026

### Puja at 12:30 PM

Griha Pravesh rituals with the family.

### Bhojan from 2:00 PM

A Rajasthani thali, served with love.

### Near Hanuman Vatika, Pokaran

Rajasthan. The map opens at Hanuman Vatika and our home is close by.

Come hungry, leave blessed.

[Get directions](https://www.google.com/maps/search/?api=1&query=Hanuman+Vatika+Pokaran+Rajasthan) [Add to calendar](#)

The caravan is on its way

Near Hanuman Vatika · Pokaran

राम राम सा · खम्मा घणी!

## पधारज्यो!

Your blessings will make our new home complete.

[RSVP on WhatsApp](#)

With love, The Vyas Family